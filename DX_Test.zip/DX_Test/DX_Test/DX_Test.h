#pragma once

#include "resource.h"
#include <Base/EngineMath.h>

void SetWindowPosAndScale(FVector _Pos, FVector _Scale);