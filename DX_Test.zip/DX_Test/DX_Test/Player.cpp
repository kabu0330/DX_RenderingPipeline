#include "PreCompile.h"
#include "Player.h"
#include "ComponentRenderer.h"

APlayer::APlayer()
{
	PlayerRenderer = CreateDefaultSubObject<UComponentRenderer>();
}

APlayer::~APlayer()
{
}

void APlayer::BeginPlay()
{
}

void APlayer::Tick(float _DeltaTime)
{
}

