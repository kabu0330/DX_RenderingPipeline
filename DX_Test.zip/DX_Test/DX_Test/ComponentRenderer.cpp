#include "PreCompile.h"
#include "ComponentRenderer.h"

UComponentRenderer::UComponentRenderer()
{
}

UComponentRenderer::~UComponentRenderer()
{
}

